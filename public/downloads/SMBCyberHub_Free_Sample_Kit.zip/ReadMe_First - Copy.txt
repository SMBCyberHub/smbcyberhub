📂 SMBCyberHub – Free Sample Kit
Version: July 2025

👋 Welcome – and thanks for checking out the SMBCyberHub Free Sample Kit.

This folder contains a preview of our Pro Kit, designed to help small teams (1–20 employees) improve cybersecurity awareness and prepare for audits, vendor reviews, or cyber insurance applications – fast.

🧾 What's Included:
- ✅ Cyber Hygiene Checklist (PDF)  
  A simple one-page checklist used by teams for quarterly hygiene checks or audit prep.

- ✅ Sample Training Quiz (PDF)  
  Includes 3 real-world awareness questions covering remote work, passwords, and MFA – with answers and rationale.

- ✅ Pro Kit Overview (PDF)  
  A one-page breakdown of what’s included in the full SMBCyberHub Pro Kit, including editable training slides, policies, and tracking tools.

💡 How to Use This Kit:
1. Open the Checklist and Quiz to get a feel for the tone, clarity, and coverage.
2. Review the Overview to see what's included in the full version.
3. Share internally with your office manager, IT lead, or security contact if helpful.

🔐 About SMBCyberHub:
Our kits are built for non-technical teams that need to get compliant quickly – without SaaS, logins, or complexity. All files are one-time downloads and audit-friendly.

🌐 Ready to upgrade?  
Explore the full Pro Kit here:  
https://www.smbcyberhub.com

Thanks again,  
— The SMBCyberHub Team  
(Founder-led, no-fluff, compliance-aligned)